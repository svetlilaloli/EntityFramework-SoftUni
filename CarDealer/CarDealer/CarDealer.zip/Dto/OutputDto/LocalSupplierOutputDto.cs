﻿namespace CarDealer.Dto.OutputDto
{
    public class LocalSupplierOutputDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int PartsCount { get; set; }
    }
}
