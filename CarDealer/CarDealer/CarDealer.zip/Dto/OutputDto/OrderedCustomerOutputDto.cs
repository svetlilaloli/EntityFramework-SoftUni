﻿namespace CarDealer.Dto.OutputDto
{
    public class OrderedCustomerOutputDto
    {
        public string Name { get; set; }
        public string BirthDate { get; set; }
        public bool IsYoungDriver { get; set; }
    }
}
